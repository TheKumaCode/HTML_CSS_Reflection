<?php 

$dbServerName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "netmatters";

// $dbServerName = "localhost";
// $dbUsername = "robertas_vildziunas";
// $dbPassword = "8H6KgUo0uU~$";
// $dbName = "robertas_netmatters";

$connect = mysqli_connect($dbServerName, $dbUsername, $dbPassword, $dbName);


    